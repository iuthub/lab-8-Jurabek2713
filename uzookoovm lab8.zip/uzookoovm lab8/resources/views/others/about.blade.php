@extends('layouts.master')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <p class="quote">About Me</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt consequatur delectus quam dicta enim, 
            sed fugiat asperiores, minus quo accusantium ipsum consequuntur ipsam aut, porro exercitationem id voluptatem sapiente aliquam.</p>
            
        </div>
    </div>
    
@endsection